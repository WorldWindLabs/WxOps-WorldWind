﻿Imports VB = Microsoft.VisualBasic
Imports System
Imports System.IO
Imports System.Diagnostics

Public Class Form1
    Dim path As String = "c:\test1"
    Dim com As String = "cmd.txt"
    Dim response As String = "response.txt"

    Dim comObject As String = path & "\" & com
    Dim responseObject As String = path & "\" & response

    Dim MyFS As VB.MyServices.FileSystemProxy = My.Computer.FileSystem
    Public watcher As FileSystemWatcher

    'SET POV command
    'strategy is to write setpov cmd string to file cmd.txt
    'WWE is listening for file cmd.txt change
    'upon detection, WWE sets POV in WWE, then attempts to delete file cmd.txt
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'fetch params from UI
        Dim lon As String = Trim(TextBox1.Text) & ","
        Dim lat As String = Trim(TextBox2.Text) & ","
        Dim rng As String = Trim(TextBox3.Text) & ","
        Dim roll As String = Trim(TextBox4.Text) & ","
        Dim tilt As String = Trim(TextBox5.Text) & ","
        Dim azi As String = Trim(TextBox6.Text) & ","
        Dim FOV As String = Trim(TextBox7.Text) & ","
        Dim spd As String = Trim(TextBox8.Text) 'teleport only = 5
        'assemble the cmd string
        'pov,-155,25,19070000,0,0,0,45,5"
        Dim cmd As String = "setpov," & lon & lat & rng & roll & tilt & azi & FOV & spd
        Try
            MyFS.WriteAllText(comObject, cmd, False)
        Catch ex As Exception
            MsgBox("WxOps", MsgBoxStyle.Exclamation, ex.ToString)
        End Try
    End Sub

    'GET POV command
    'strategy is to write getpov cmd string to file cmd.txt
    'WWE is listening for file cmd.txt change
    'upon detection, WWE reads POV and returns result in file response.txt, then attempts to delete file cmd.txt
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'start the watcher for file response.txt (create, change)
        watcher.EnableRaisingEvents = True

        '******************************
        'emulation of JAVA response -> response.txt
        'instead this should write to cmd.txt, and WWE creates response.txt
        Dim cmd As String = "getpov"
        Try
            MyFS.WriteAllText(comObject, cmd, False)
        Catch ex As Exception
            MsgBox("WxOps cmd=getPOV", MsgBoxStyle.Exclamation, ex.ToString)
        End Try
        '******************************

    End Sub

    'we need a timeout, for case where WWE does not respond


    'FileSystemWatcher for "response.txt" create OR modify
    Private Sub watcherAction(ByVal source As Object, ByVal e As System.IO.FileSystemEventArgs)
        If e.Name = response Then 'WWE has responded
            If (e.ChangeType = WatcherChangeTypes.Created) Or (e.ChangeType = WatcherChangeTypes.Changed) Then

                watcher.EnableRaisingEvents = False
                fileObject = e.FullPath
                Timeout = 10

                'MsgBox(fileObject & " = " & e.ChangeType.ToString & " WAIT FOR IT")
                'Use timer1 to poll fileObject until successful read

                Timer1.Enabled = True


                

            End If
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Not MyFS.DirectoryExists(path) Then
            Try
                MyFS.CreateDirectory(path)
            Catch ex As Exception
                MsgBox("cannot create directory " & path)
                Exit Sub
            End Try
        End If

        watcher = New System.IO.FileSystemWatcher
        watcher.SynchronizingObject = Me

        watcher.Path = path
        watcher.NotifyFilter = IO.NotifyFilters.DirectoryName Or IO.NotifyFilters.FileName Or IO.NotifyFilters.Attributes
        AddHandler watcher.Changed, AddressOf watcherAction
        AddHandler watcher.Created, AddressOf watcherAction
        AddHandler watcher.Deleted, AddressOf watcherAction
        AddHandler watcher.Renamed, AddressOf watcherAction
    End Sub

    Public cmdstring As String = ""
    Dim fileObject As String = ""
    Dim Timeout As Integer = 10

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Timer1.Enabled = False
        Timeout = Timeout - 1
        If Timeout < 0 Then
            MsgBox("WxOps timeout", MsgBoxStyle.Exclamation, "failed to acquire response")
            Exit Sub
        End If


        Dim cmd1 As String = ""
        Try
            cmd1 = MyFS.ReadAllText(fileObject) & vbCrLf
        Catch ex As Exception
            'MsgBox("WxOps read response", MsgBoxStyle.Exclamation, ex.ToString)
            Timer1.Enabled = True 'try again
        End Try

        'success!!
        'MsgBox(e.FullPath & " = " & e.ChangeType.ToString)

        If InStr("getpov", cmd1) >= 0 Then
            cmdstring = cmd1 'pass cmd to another thread
            ' MsgBox(cmdstring)
            Dim cmd2 As String = cmd1 & vbCrLf
            Try
                MyFS.WriteAllText(path & "\logout.txt", cmd2, True) 'Append response to log
                If MyFS.FileExists(fileObject) Then
                    MyFS.DeleteFile(fileObject)
                End If
            Catch ex As Exception
                MsgBox("WxOps delete response", MsgBoxStyle.Exclamation, ex.ToString)
            End Try
            'MsgBox("heya")
            Dim arg() As String = Split(cmdstring, ",")
            If arg.Length >= 9 Then
                TextBox1.Text = arg(1)
                TextBox2.Text = arg(2)
                TextBox3.Text = arg(3)
                TextBox4.Text = arg(4)
                TextBox5.Text = arg(5)
                TextBox6.Text = arg(6)
                TextBox7.Text = arg(7)
                TextBox8.Text = arg(8)
            End If
        End If

    End Sub
End Class


